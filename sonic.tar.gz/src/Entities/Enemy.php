<?php

namespace SonicGame\Entities;

class Enemy
{

}

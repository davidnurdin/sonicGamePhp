<?php


namespace SonicGame\Service;

class SampleClass
{

    public function __construct()
    {
        // Constructor logic here
    }

    public function sampleMethod()
    {
        // Sample method logic here
        return "Hello, World!";
    }

}

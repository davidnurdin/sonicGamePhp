#!/bin/bash

php -d 'extension=sdl.so' app.php

